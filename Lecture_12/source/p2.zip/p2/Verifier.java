public interface Verifier {
    boolean check(int[] guess, int[] answer);
}

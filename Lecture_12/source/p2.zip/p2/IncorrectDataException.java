class IncorrectDataException extends Exception {
    // Exception class for incorrect data
}

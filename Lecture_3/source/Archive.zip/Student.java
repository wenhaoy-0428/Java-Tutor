public record Student(String name, int mark) {
}